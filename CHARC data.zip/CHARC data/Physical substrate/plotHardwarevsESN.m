function plotHardwarevsESN(resName,esnSize)

%select ESN to compare to
switch(esnSize)
    case 25
        database1 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\25 nodes\noveltySearch3D_size25_run10_gens2000.mat', 'all_databases');
        database1_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\25 nodes\noveltySearch3D_size25_run10_gens2000.mat', 'total_space_covered');
        database1_ts_rand = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_25.mat', 'total_space_covered');        
        database1_name = '25 node ESN';
    case 50
        database1 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\50 nodes\noveltySearch3D_size50_run10_gens2000.mat', 'all_databases');
        database1_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\50 nodes\noveltySearch3D_size50_run10_gens2000.mat', 'total_space_covered');
        database1_ts_rand = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_50.mat', 'total_space_covered');
        database1_name = '50 node ESN';
    case 100
        database1 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\100 nodes\noveltySearch3D_size100_run10_gens2000.mat', 'all_databases');
        database1_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\100 nodes\noveltySearch3D_size100_run10_gens2000.mat', 'total_space_covered');
        database1_ts_rand = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_100.mat', 'total_space_covered');
        database1_name = '100 node ESN';
    case 200
        database1 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\200 nodes\noveltySearch3D_size200_run10_gens2000.mat', 'all_databases');
        database1_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\200 nodes\noveltySearch3D_size200_run10_gens2000.mat', 'total_space_covered');       
        database1_ts_rand = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_200.mat', 'total_space_covered');
        database1_name = '200 node ESN';
end


for p = 1:length(resName)
    switch(resName{p}) 
        case 'B2S164'
        %% plot 25
        database2 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Carbon nanotubes\hardware_noveltySearch_2000_SN_B2S164_run_5.mat', 'all_databases');
        database2_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Carbon nanotubes\hardware_noveltySearch_2000_SN_B2S164_run_5.mat', 'total_space_covered');
        database2_ts_rand = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Carbon nanotubes\hardware_randSearch_2000_SN_B2S164_run_5.mat', 'total_space_covered');
        
        database2_name = resName{p};
        
        plotDatabases(figure,database2_ts.total_space_covered([1 3 4 5],:),database1_ts.total_space_covered([1 3 4 5],:),database2_name,database1_name,1)
        print(strcat('B2S164vsESN',num2str(esnSize),'_coverage'),'-dpdf','-bestfit')
        
        plotDB1 =[]; plotDB2 =[];
        for i = 1:size(database2.all_databases,1)
            plotDB1 = [plotDB1;database1.all_databases{i,10}];
            plotDB2 = [plotDB2;database2.all_databases{i,10}];
        end
        plotDatabaseComparison(figure,plotDB1,plotDB2,database1_name,database2_name,1)
        print(strcat('B2S164vsESN',num2str(esnSize),'_BS'),'-dpdf','-bestfit')
        
        databases{p,1} = database1_ts.total_space_covered([1 3 4 5],:);% ESN
        databases{p,2} = database2_ts.total_space_covered([1 3 4 5],:);% Material
        
        origData{p,1} = database1_ts_rand.total_space_covered([1 3 4 5],:);% Material
        origData{p,2} = database2_ts_rand.total_space_covered([1 3 4 5],:);% Material
        
        plotJoinedDatabases(figure,databases,origData,esnSize,resName{p})
        print(strcat('ratioOfSameSpace_',resName{p},'ESN'),'-dpdf','-bestfit')

        case 'mutliSub'
        
        %% plot 25
        database2 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\MultiSubstrate test\hardware_noveltySearch_2000_SN_mutliSub_run_5.mat', 'all_databases');
        database2_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\MultiSubstrate test\hardware_noveltySearch_2000_SN_mutliSub_run_5.mat', 'total_space_covered');
        database2_ts_rand = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\MultiSubstrate test\hardware_noveltySearch_2000_SN_mutliSub_run_5.mat', 'total_space_covered');
        
        database2_name = resName{p};
        
        plotDatabases(figure,database2_ts.total_space_covered([1 3 4 5],:),database1_ts.total_space_covered([1 3 4 5],:),database2_name,database1_name,1)
        print(strcat('mutliSubvsESN',num2str(esnSize),'_coverage'),'-dpdf','-bestfit')
        
        plotDB1 =[]; plotDB2 =[];
        for i = 1:size(database2.all_databases,1)
            plotDB1 = [plotDB1;database1.all_databases{i,10}];
            plotDB2 = [plotDB2;database2.all_databases{i,10}];
        end
        plotDatabaseComparison(figure,plotDB1,plotDB2,database1_name,database2_name,1)
        print(strcat('mutliSubvsESN',num2str(esnSize),'_BS'),'-dpdf','-bestfit')
        
        databases{p,1} = database1_ts.total_space_covered([1 3 4 5],:);% ESN
        databases{p,2} = database2_ts.total_space_covered([1 3 4 5],:);% Material
        
        origData{p,1} = database1_ts_rand.total_space_covered([1 3 4 5],:);% Material
        origData{p,2} = database2_ts_rand.total_space_covered([1 3 4 5],:);% Material
        
        plotJoinedDatabases(figure,databases,origData,esnSize,resName{p})
        print(strcat('ratioOfSameSpace_',resName{p},'ESN'),'-dpdf','-bestfit')
        
     case 'IronDrop1'
        
        %% plot 25
        database2 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Iron nanoparticles\hardware_noveltySearch_2000_SN_drop1_run_2.mat', 'all_databases');
        database2_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Iron nanoparticles\hardware_noveltySearch_2000_SN_drop1_run_2.mat', 'total_space_covered');
        database2_ts_rand = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Iron nanoparticles\hardware_noveltySearch_2000_SN_drop1_run_2.mat', 'total_space_covered');
        
        database2_name = resName{p};
        
        plotDatabases(figure,database2_ts.total_space_covered,database1_ts.total_space_covered,database2_name,database1_name,1)
        print(strcat('mutliSubvsESN',num2str(esnSize),'_coverage'),'-dpdf','-bestfit')
        
        plotDB1 =[]; plotDB2 =[];
        for i = 1:size(database2.all_databases,1)
            plotDB1 = [plotDB1;database1.all_databases{i,10}];
            plotDB2 = [plotDB2;database2.all_databases{i,10}];
        end
        plotDatabaseComparison(figure,plotDB1,plotDB2,database1_name,database2_name,1)
        print(strcat('mutliSubvsESN',num2str(esnSize),'_BS'),'-dpdf','-bestfit')
        
        databases{p,1} = database1_ts.total_space_covered;% ESN
        databases{p,2} = database2_ts.total_space_covered;% Material
        
        origData{p,1} = database1_ts_rand.total_space_covered;% Material
        origData{p,2} = database2_ts_rand.total_space_covered;% Material
        
        plotJoinedDatabases(figure,databases,origData,esnSize,resName{p})
        print(strcat('ratioOfSameSpace_',resName{p},'ESN'),'-dpdf','-bestfit')

    end
%     %% plot 50
%     if resize(p) == 50
%         database1 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\50 nodes\noveltySearch3D_size50_run10_gens2000.mat', 'all_databases');
%         database1_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\50 nodes\noveltySearch3D_size50_run10_gens2000.mat', 'total_space_covered');
%         database2= load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_50.mat', 'all_databases');
%         database2_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_50.mat', 'total_space_covered');
%         database1_name = 'NS 50 node';
%         database2_name = 'Random 50 node';
%         
%         plotDatabases(figure,database1_ts.total_space_covered,database2_ts.total_space_covered,database1_name,database2_name)
%         print('50node_coverage','-dpdf','-bestfit')
%         
%         plotDB1 =[]; plotDB2 =[];
%         for i = 1:length(database1.all_databases)
%             plotDB1 = [plotDB1;database1.all_databases{i,10}];
%             plotDB2 = [plotDB2;database2.all_databases{i,10}];
%         end
%         plotDatabaseComparison(figure,plotDB1,plotDB2,database1_name,database2_name)
%         print('50node_BS','-dpdf','-bestfit')
%     end

end



function plotJoinedDatabases(figureHandle1,databases,origData,resize,resName)

set(0,'currentFigure',figureHandle1)
x = 0:10;
labels = {'-','-','-','-'};%{'-','--',':','-.'};

for d = 1:size(databases,1)
    
    database1 = databases{d,1}; %ESN
    database2 = databases{d,2}; %Material
    database3 = origData{d,1}; %ESN
    database4 = origData{d,2}; %Material(random)
    
    rand_db1 = origData{d,1}; %ESN
    rand_db2 = origData{d,2}; %Material
    
    % take into account first 200 in population for random search
    for i = 1:size(database1,1)
        database1(i,2:end) = database1(i,1:end-1);
        database1(i,1) = rand_db1(i,1);
        
        database2(i,2:end) = database2(i,1:end-1);
        database2(i,1) = rand_db2(i,1);
    end
    
    database1 = database1./[200:200:2000];
    database2 = database2./[200:200:2000];
    database3 = database3./[200:200:2000];
    database4 = database4./[200:200:2000];
    
    y = mean(database1);
    L = y - min(database1);
    U = max(database1) - y;
    errorbar(x,[0 y(1:end)],[0 L(1:end)],[0 U(1:end)],'lineStyle',labels{d},'color',[0 0 0])
    %text(x(end)+0.15,y(end),strcat('ESN ',num2str(resize(d))))
    
    hold on
    
    y = mean(database2);
    L = y - min(database2);
    U = max(database2) - y;
    errorbar(x,[0 y(1:end)],[0 L(1:end)],[0 U(1:end)],'lineStyle',labels{d},'color',[1 0 0])
    %text(x(end)+0.15,y(end),resName)
    
    y = mean(database3);
    L = y - min(database3);
    U = max(database3) - y;
    errorbar(x,[0 y(1:end)],[0 L(1:end)],[0 U(1:end)],'lineStyle','--','color',[0 0 0])
    %text(x(end)+0.15,y(end),{'ESN','\n(Random)'})
    
    y = mean(database4);
    L = y - min(database4);
    U = max(database4) - y;
    errorbar(x,[0 y(1:end)],[0 L(1:end)],[0 U(1:end)],'lineStyle','--','color',[1 0 0])
    %text(x(end)+0.15,y(end)-0.05,{resName,'(Random)'})
   
end
hold off

lb = 0:200:2000;
xticklabels(lb)
xlim([1 10])
%ylim([0 0.00025])
grid on
xlabel('Generations')
ylabel('r')
lg = legend(strcat('ESN ',num2str(resize(d))),resName,strcat('ESN ',num2str(resize(d)),'(random)'),strcat(resName,' (random)'),'Location','northeast');
%set(gca, 'YScale', 'log')
set(gca,'FontSize',12,'FontName','Arial')
%set(lg,'FontSize',12)

set(gcf,'renderer','OpenGL')
drawnow