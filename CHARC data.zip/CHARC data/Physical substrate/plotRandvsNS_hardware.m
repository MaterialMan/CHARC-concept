function plotRandvsNS_hardware(resName)

for p = 1:length(resName)
    switch(resName{p}) 
        case 'B2S164'
        %% plot 25
        database1 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Carbon nanotubes\hardware_noveltySearch_2000_SN_B2S164_run_5.mat', 'all_databases');
        database1_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Carbon nanotubes\hardware_noveltySearch_2000_SN_B2S164_run_5.mat', 'total_space_covered');
        
        database2= load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Carbon nanotubes\hardware_randSearch_2000_SN_B2S164_run_5.mat', 'all_databases');
        database2_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\Physical\Carbon nanotubes\hardware_randSearch_2000_SN_B2S164_run_5.mat', 'total_space_covered');
        
        database1_name = 'Novelty Search';
        database2_name = 'Random Search';
        
        plotDatabases(figure,database1_ts.total_space_covered([1 3 4 5],:),database2_ts.total_space_covered([1 3 4 5],:),database1_name,database2_name)
        print('B2S164_coverage','-dpdf','-bestfit')
        
        plotDB1 =[]; plotDB2 =[];
        for i = 1:size(database1.all_databases,1)
            plotDB1 = [plotDB1;database1.all_databases{i,10}]; 
            plotDB2 = [plotDB2;database2.all_databases{i,10}];
        end
        plotDatabaseComparison(figure,plotDB1,plotDB2,database1_name,database2_name)
        print('B2S164_BS','-dpdf','-bestfit')
        
    end
%     %% plot 50
%     if resize(p) == 50
%         database1 = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\50 nodes\noveltySearch3D_size50_run10_gens2000.mat', 'all_databases');
%         database1_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\50 nodes\noveltySearch3D_size50_run10_gens2000.mat', 'total_space_covered');
%         database2= load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_50.mat', 'all_databases');
%         database2_ts = load('Z:\Working_code_repo\SQuARC\Squarc Framework\Journal Results\ESNs\Random Search\randSearch_3DGPU_Nres_50.mat', 'total_space_covered');
%         database1_name = 'NS 50 node';
%         database2_name = 'Random 50 node';
%         
%         plotDatabases(figure,database1_ts.total_space_covered,database2_ts.total_space_covered,database1_name,database2_name)
%         print('50node_coverage','-dpdf','-bestfit')
%         
%         plotDB1 =[]; plotDB2 =[];
%         for i = 1:length(database1.all_databases)
%             plotDB1 = [plotDB1;database1.all_databases{i,10}];
%             plotDB2 = [plotDB2;database2.all_databases{i,10}];
%         end
%         plotDatabaseComparison(figure,plotDB1,plotDB2,database1_name,database2_name)
%         print('50node_BS','-dpdf','-bestfit')
%     end

end
